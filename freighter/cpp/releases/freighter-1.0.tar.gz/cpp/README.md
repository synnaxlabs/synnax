**Setting up the Dev Environment**

* **Bazel:** The build system. For more information on how Bazel's build system works, see: https://bazel.build/
  * Installation:
    * Linux: https://bazel.build/install/u
  * Usage:
    * Building with Bazel is easy! Check out the Bazel docs to see how to set up your project.
    * Simply include the library you want to use from this repo
